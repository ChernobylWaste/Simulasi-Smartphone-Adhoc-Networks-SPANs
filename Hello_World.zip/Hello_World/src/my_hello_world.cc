/*
 * my_hello_world.cc
 *
 *  Created on: Nov 1, 2021
 *      Author: hp
 */

#include <omnetpp.h>

using namespace omnetpp;

class percobaan: public cSimpleModule
{
protected:
    void initialize() override;
    void handleMessage(cMessage *msg) override;
};

Define_Module(percobaan);

void percobaan::initialize()
{
    if(strcmp("Computer2",getName())==0)
    {
        cMessage *msg = new cMessage("Hai Kamu!");

        send(msg, "output_gate");
    }
}

void percobaan::handleMessage(cMessage *msg)
{
    send(msg, "output_gate");
}
